<?php $adminSteamID = '76561198080574798'; ?>
