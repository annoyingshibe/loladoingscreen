<div class="row">
	<div class="col s12">
		<div class="card">
			<div class="card-content">
				<p class="flow-text light"><span id="dlstatus">Retrieving server info...</span></p>
				<p class="flow-text light" style="font-size: 16px"><i class="fa fa-download"></i><span id="curfilename"> No files downloading</span></p>
				<div class="progress">
					<div id="progressbar" class="determinate" style="width: 0%"></div>
				</div>
			</div>
		</div>
	</div>
</div>
